import tkinter as tk
from tkinter import *
from tkinter.font import Font
from keras.models import load_model
from keras.utils import load_img, img_to_array
import os
from PIL import Image, ImageTk

# Đường dẫn đến thư mục test_set
test_set_dir = "D:/PHUC/Mon AI/Cu-Qua_dataset/test_set"

# Load mô hình đã được huấn luyện
model = load_model('cu_qua.h5')

# Hàm xử lý khi người dùng nhấn nút tìm kiếm
def search():
    # Lấy tên củ quả người dùng nhập
    fruit_name = entry.get()

    # Vị trí ban đầu của hàng và cột
    x = 50
    y = 120
    # Kiểm tra tên củ quả và hiển thị hình ảnh tương ứng
    if fruit_name in fruit_images:
        # Hiển thị 6 hình ảnh và tên của củ quả
        for i in range(6):
            img_path = os.path.join(test_set_dir, fruit_images[fruit_name][i])
            img = load_img(img_path, target_size=(50, 50))
            img = img_to_array(img)
            img = img / 255.0
            img = img.reshape(1, 50, 50, 3)

            prediction = model.predict(img)
            predicted_class = prediction.argmax()

            image_display = Image.open(img_path)
            photo = ImageTk.PhotoImage(image_display)
            label = tk.Label(window, image=photo, font='arial', bg='#d14f4f')
            label.image = photo
            # Tính toán vị trí của tấm hình
            row = i // 2  # Số hàng
            column = i % 2  # Số cột
            label.place(x=x + column * 100, y=y + row * 100)
            # Tên loại củ quả
            label_name = tk.Label(window, text=fruit_name, bg='#aa7ade', fg='white')
            label_name.place(x=x + 12 + column * 100, y=y + row * 100 + 75)
    
    else:
        # Hiển thị thông báo khi không tìm thấy củ quả
        label_error = tk.Label(window, text="Không tìm thấy củ quả.")
        label_error.place(x=10, y=65)

# Tạo cửa sổ giao diện
window = tk.Tk()
window.geometry('280x480')
window.title('Vegetables Identification')
window.configure(background='#fcf58d')

# Tạo label và entry để người dùng nhập tên củ quả
bold_font = Font(family="arial", size=15, weight="bold")
label = tk.Label(window, font= bold_font, text="Nhập tên củ quả: ", bg="#52f295", fg="#d488fc")
label.place(x=10,y=10)

entry = tk.Entry(window)
entry.place(x=30, y=45)

# Tạo nút tìm kiếm
button = tk.Button(window, text="Search", font=bold_font, command=search, bg="#52f295", fg="#d488fc" )
button.place (x=190, y=30)  # Đặt button ở tọa độ (190, 30)

# Định nghĩa danh sách hình ảnh của các loại củ quả
fruit_images = {
    "Ca Rot": ["carot(1).jpg", "carot(2).jpg", "carot(3).jpg", "carot(4).jpg", "carot(5).jpg",
               "carot(6).jpg", "carot(7).jpg", "carot(8).jpg", "carot(9).jpg", "carot(10).jpg" ],
    "Bi Dao": ["bi_dao(1).jpg", "bi_dao(2).jpg", "bi_dao(3).jpg", "bi_dao(4).jpg", "bi_dao(5).jpg",
               "bi_dao(6).jpg", "bi_dao(7).jpg", "bi_dao(8).jpg", "bi_dao(9).jpg", "bi_dao(10).jpg"],
    "Bi Do": ["bi do (1).jpg","bi do (2).jpg","bi do (3).jpg","bi do (4).jpg","bi do (5).jpg",
              "bi do (6).jpg","bi do (7).jpg","bi do (8).jpg","bi do (9).jpg","bi do (10).jpg"],
    "Cu Den": ["cu den (5).jpg","cu den (1).jpg","cu den (2).jpg","cu den (3).jpg","cu den (4).jpg",
               "cu den (6).jpg","cu den (7).jpg","cu den (8).jpg","cu den (9).jpg","cu den (10).jpg"],
    "Khoai Lang": ["khoai lang (5).jpg","khoai lang (1).jpg","khoai lang (2).jpg","khoai lang (3).jpg","khoai lang (4).jpg",
                   "khoai lang (6).jpg","khoai lang (7).jpg","khoai lang (8).jpg","khoai lang (9).jpg","khoai lang (10).jpg"],
    "Khoai Tay": ["khoai tay (5).jpg","khoai tay (1).jpg","khoai tay (2).jpg","khoai tay (3).jpg","khoai tay (4).jpg",
                  "khoai tay (6).jpg","khoai tay (7).jpg","khoai tay (8).jpg","khoai tay (9).jpg","khoai tay (10).jpg"],
    "Dua Leo": ["dua leo (5).jpg","dua leo (1).jpg","dua leo (2).jpg","dua leo (3).jpg","dua leo (4).jpg",
                "dua leo (6).jpg","dua leo (7).jpg","dua leo (8).jpg","dua leo (9).jpg","dua leo (10).jpg"],
    "Cai Trang": ["cai trang (5).jpg","cai trang (1).jpg","cai trang (2).jpg","cai trang (3).jpg","cai trang (4).jpg",
                  "cai trang (6).jpg","cai trang (7).jpg","cai trang (8).jpg","cai trang (9).jpg","cai trang (10).jpg"],
    "Ot Hiem": ["ot hiem (5).jpg","ot hiem (1).jpg","ot hiem (2).jpg","ot hiem (3).jpg","ot hiem (4).jpg",
                "ot hiem (6).jpg","ot hiem (7).jpg","ot hiem (8).jpg","ot hiem (9).jpg","ot hiem (10).jpg"],
    "Ot chuong": ["ot vang (5).jpg","ot vang (1).jpg","ot vang (2).jpg","ot vang (3).jpg","ot vang (4).jpg",
                "ot vang (6).jpg","ot vang (7).jpg","ot vang (8).jpg","ot vang (9).jpg","ot vang (10).jpg"]
}

# Hiển thị cửa sổ giao diện
window.mainloop()

